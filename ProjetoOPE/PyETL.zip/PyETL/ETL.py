from Bussines import BussinesETL

print('Inciando Coleta:')
caminho = input('informe o caminho para coleta: ..')

#chamada etl
Resultado = BussinesETL.Execution.Import(caminho)



